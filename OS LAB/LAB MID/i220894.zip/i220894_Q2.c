#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() 
{
    int arr1[2], arr2[2];
    pipe(arr1); 
    pipe(arr2); 

    int p1 = fork();
    if (p1 == 0) 
    {
        close(arr1[1]);
        close(arr2[0]);
    
        int arr3[10];
    
        read(arr1[0], arr3, sizeof(arr3));

        for (int i = 0; i < 10; i++)
           {
            arr3[i] = arr3[i] * arr3[i];
           }

        write(arr2[1], arr3, sizeof(arr3));
    } 
    else 
    {
        close(arr1[0]);
        close(arr2[1]);
      
        int arr4[10];
      
        for (int i = 0; i < 10; i++)
            arr4[i] = i + 1;

        write(arr1[1], arr4, sizeof(arr4));
        read(arr2[0], arr4, sizeof(arr4));

        printf("Showing the numbers : --> :\n");
        for (int i = 0; i < 10; i++)
	{
	  printf("%d ", arr4[i]);
	}
      
      
        printf("\n");
    }
    
    
    return 0;
}

