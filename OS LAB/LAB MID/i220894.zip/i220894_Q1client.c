#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>


int main() 
{

char* ch1= "client_pipe";
char* ch2= "server_pipe";
char buffer[100];

    int write_var = open(ch1, O_WRONLY);
    int read_var = open(ch2, O_RDONLY);

    while (1) 
    {
        printf("\nEnter string : ");
        fgets(buffer, sizeof(buffer), stdin);
        
        write(write_var, buffer, strlen(buffer));

        read(read_var, buffer, sizeof(buffer));
       
        printf("Server Side --> : %s", buffer);

        if (buffer== "exit")
         {
	  break;
         }

    }

    close(write_var);
    close(read_var);

    return 0;
}

