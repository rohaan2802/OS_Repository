#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/wait.h>

int main() 
{
    int p1 = fork();
    
    if (p1 == 0) 
    {
        printf("Child_1 \n");
        execlp("ls", "ls", "-l", NULL);
    }
    else 
    {
        int p2 = fork();

        if (p2 == 0) 
        {
              printf("Child_2\n");
	    execlp("echo", "echo", "Hello, World!",NULL);
        }
        else 
        {
            printf("Waiting Parent_2\n");
            wait(NULL);
            wait(NULL);
            printf("Waiting Parent_1\n");

        }
    }
    return 0;
}

