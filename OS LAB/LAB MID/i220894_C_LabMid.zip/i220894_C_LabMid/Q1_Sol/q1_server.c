#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>



int balance = 1000; 

int main() 
{
    char buffer[256];
    char* ch1[50]= "client_pipe";
    char* ch2[50]= "server_pipe";
    
    mkfifo(ch1, 0666);
    mkfifo(ch2, 0666);

    int read_var = open(ch1, O_RDONLY);
    int write_var = open(ch2, O_WRONLY);

    while (1) 
    {
    
        read(read_var, buffer, sizeof(buffer));

        if (buffer=="exit") 
        {
            break;
        }
        else if (buffer=="deposit ")
        {
            int amount = buffer + 8;
            balance += amount;
        }
        else if (buffer=="withdraw ") 
        {
            int amount = buffer + 9;
            balance -= amount;
        } 
        else if (buffer=="balance") 
        {
            printf("balance ---> %d",buffer);
        } 
     
       write(write_var, buffer, strlen(buffer));
    
    }

    close(read_var);
    close(write_var);

}

