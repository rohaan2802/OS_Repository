#include <iostream>
#include <sstream>
#include <cstring>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
 
using namespace std;

int main() {
    string line, input, output;
    cout << "myshell> ";
    getline(cin, line);

    stringstream ss(line);
    string token;
    char* args[10];  
    int index = 0;
    
    while (ss >> token) {
        if (token == "<") {
            ss >> input;
        } 
        else if (token == ">") {
            ss >> output;
        } 
        else {
            char* arg = new char[token.size() + 1];
            strcpy(arg, token.c_str());
            args[index++] = arg;
        }
       }

    args[index] = NULL;

    pid_t pid = fork();
    if (pid == 0) {
      if (!input.empty()) {
          int in = open(input.c_str(), O_RDONLY);
          dup2(in, STDIN_FILENO);
          close(in);
       }


    if (!output.empty()) {
        int out = open(output.c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0644);       
        dup2(out, STDOUT_FILENO);
        close(out);
        }

        execvp(args[0], args);
        cout << "Exec failed" << endl;
        return 1;
    } else if (pid > 0) {
        wait(NULL);
    }

    return 0;
}

