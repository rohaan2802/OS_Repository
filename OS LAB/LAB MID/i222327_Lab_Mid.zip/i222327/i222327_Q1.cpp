#include <iostream>
#include <unistd.h>
#include <sys/wait.h>

using namespace std;

int main(int argc, char* argv[]) {
  
  for (int i = 1; i < argc; i++) {
        pid_t pid = fork();

      if (pid == 0) {
          execlp(argv[i], argv[i], NULL);
          cout << "Failed to execute the command:" << argv[i] << endl;
          return 1;
         } else if (pid > 0) {
          wait(NULL);
          } else {
           cout << "Fork failed!" << endl;
           return 1;
         }
   }
    return 0;
} 

