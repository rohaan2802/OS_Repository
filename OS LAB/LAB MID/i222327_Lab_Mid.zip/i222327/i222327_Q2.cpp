#include <iostream>
#include <fstream>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
using namespace std;

int main() {

    const char* pipeName = "mypipe";
    mkfifo(pipeName, 0666);

    pid_t pid = fork();
    if (pid < 0) 
    {
    cout << "fork failed" << endl;
    return 1;
    }

    if (pid == 0) {
        ifstream pipe(pipeName);
    
     string input;
      while (getline(pipe, input)) {
       pid_t execpid = fork();
       if (execpid == 0) {
        execlp(input.c_str(), input.c_str(), NULL);
        cout << "Failed to execute " << input << endl;
         return 1;
             } 
        else if (execpid > 0) 
       { 
        wait(NULL);
        } 
        else 
       {
        cout << "Fork doesnt work" << endl;
         return 1;
      }
     } 
        pipe.close();
    } 
    else 
    {
      ofstream pipe(pipeName);
      pipe << "ls"<< endl;
      pipe << "cat"<< endl;
      pipe << "grep main" << endl;
      pipe.close();
      wait(NULL); 
    }

    unlink(pipeName);
    return 0;
}

